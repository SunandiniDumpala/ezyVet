import initialState from './initialState';

const ProductReducer = (state = initialState.products, action) => {
    return state;
}

export default ProductReducer;